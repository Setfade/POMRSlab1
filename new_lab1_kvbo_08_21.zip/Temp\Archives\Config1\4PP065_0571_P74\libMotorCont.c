void FB_Integrator(void) {};
void _FB_Integrator(void) {};
void FB_Motor(void) {};
void _FB_Motor(void) {};
void FB_Regulator(void) {};
void _FB_Regulator(void) {};
