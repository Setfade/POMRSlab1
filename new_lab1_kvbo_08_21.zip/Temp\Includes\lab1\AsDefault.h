#ifndef _LAB1_DEFAULT_1000760196
#define _LAB1_DEFAULT_1000760196
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
